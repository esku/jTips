function submitbutton(pressbutton) {
	if (pressbutton == 'process') {
		slider.show();
	}
	submitform(pressbutton);
}