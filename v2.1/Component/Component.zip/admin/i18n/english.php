<?php
defined('_JEXEC') or defined('_VALID_MOS') or die('Restricted access');
/**
 * Author: Jeremy Roberts
 * Package: jTicket
 * Website: www.jtips.com.au
 * Created: 18/09/2008
 * 
 * Description: 
 * 
 * 
 */
include('master.php');

?>