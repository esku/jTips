<?php
defined('_JEXEC') or defined('_VALID_MOS') or die('Restricted Access');

/**
 * Website: www.jtips.com.au
 * @author Jeremy Roberts
 * @copyright Copyright &copy; 2009, jTips
 * @license Commercial - See website for details
 * 
 * @since 2.1.9 - 06/04/2009
 * @version 1.0.0
 * @package jTips
 * 
 * Description: apply the changes and reload the configuration page 
 */

include('save.php');